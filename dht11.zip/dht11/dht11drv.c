#include<linux/module.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/platform_device.h>
#include <asm/mach-types.h>
#include <linux/gpio.h>
#include <asm/gpio.h>
#include <asm/delay.h>
#include <linux/clk.h>
#include <mach/gpio.h>
#include <mach/soc.h>
#include <mach/platform.h>
#include <linux/slab.h>
#include <linux/input.h>
#include <linux/errno.h>
#include <linux/serio.h>
#include <linux/wait.h>
#include <linux/cdev.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <mach/gpio.h>
#include <linux/gpio.h>



#define CFG_IO_X6818_Humity (PAD_GPIO_B + 29)

static struct class *dht11drv_class;
static struct class_device	*dht11drv_class_dev;



volatile unsigned long *gpbcon;
volatile unsigned long *gpbdat;

int data_in(void) {
    gpio_direction_input(CFG_IO_X6818_Humity);
    return gpio_get_value(CFG_IO_X6818_Humity);
}

/*************************************************
*�ܽ�����Ϊ���
*************************************************/
void data_out(int data) {
    gpio_direction_output(CFG_IO_X6818_Humity, data);
}


void DHT11_Rst(void)	   
{                 
	data_out(0); 	//SET OUTPUT
	mdelay(20);//��������18ms
    data_out(1); 	//DQ=1 
	udelay(30);     	//��������20~40us
}

u8 DHT11_Check(void) 	   
{   
	u8 retry=0;
    while (data_in()&&retry<100)//DHT11������40~80us
	{
		retry++;
		udelay(1);
	};	 
	if(retry>=100)return 1;
	else retry=0;
    while (!data_in()&&retry<100)//DHT11���ͺ���ٴ�����40~80us
	{
		retry++;
		udelay(1);
	};
	if(retry>=100)return 1;	    
	return 0;
}

u8 DHT11_Read_Bit(void) 			 
{
 	u8 retry=0;
	while(data_in()&&retry<100)//�ȴ���Ϊ�͵�ƽ
	{
		retry++;
		udelay(1);
	}
	retry=0;
	while(!data_in()&&retry<100)//�ȴ���ߵ�ƽ
	{
		retry++;
		udelay(1);
	}
	udelay(40);//�ȴ�40us
	if(data_in())return 1;
	else return 0;		   
}

u8 DHT11_Read_Byte(void)    
{        
    u8 i,dat;
    dat=0;
	for (i=0;i<8;i++) 
	{
   		dat<<=1; 
	    dat|=DHT11_Read_Bit();
    }						    
    return dat;
}


u8 DHT11_Read_Data(u8 *temp,u8 *humi)    
{        
 	u8 buf[5];
	u8 i;
	DHT11_Rst();
	if(DHT11_Check()==0)
	{
		for(i=0;i<5;i++)//��ȡ40λ����
		{
			buf[i]=DHT11_Read_Byte();
		}
		if((buf[0]+buf[1]+buf[2]+buf[3])==buf[4])
		{
			*humi=buf[0];
			*temp=buf[2];
		}
	}else return 1;
	return 0;	    
}

static int second_drv_open(struct inode *inode, struct file *file)
{
	
	 //gpio_direction_input(CFG_IO_X6818_Humity);
	

	return 0;
}

ssize_t second_drv_read(struct file *file, char __user *buf, size_t size, loff_t *ppos)
{
	/* ����4�����ŵĵ�ƽ */
	unsigned int dht11_vals[2];
	u8 temperature; 		
	u8 humidity;  
	int i ;
	for (i = 0;i<15;i++)
		{
			DHT11_Read_Data(&temperature,&humidity);
			mdelay(2000);
			printk("the tem is %d,hum is %d\n",temperature,humidity);
		}
	DHT11_Read_Data(&temperature,&humidity);
	printk("the tem is %d,hum is %d\n",temperature,humidity);
	mdelay(2000);
	dht11_vals[0] = temperature;
	dht11_vals[1] = humidity;

	copy_to_user(buf, dht11_vals, sizeof(dht11_vals));
	
	return sizeof(dht11_vals);
}


static struct file_operations sencod_drv_fops = {
    .owner  =   THIS_MODULE,    /* ����һ���꣬�������ģ��ʱ�Զ�������__this_module���� */
    .open   =   second_drv_open,     
	.read	=	second_drv_read,	   
};


int major;
static int second_drv_init(void)
{
	major = register_chrdev(0, "dht11_drv", &sencod_drv_fops);

	dht11drv_class = class_create(THIS_MODULE, "dht11_drv");

	dht11drv_class_dev = device_create(dht11drv_class, NULL, MKDEV(major, 0), NULL, "dht11"); /* /dev/buttons */
	

	return 0;
}

static void second_drv_exit(void)
{
	unregister_chrdev(major, "dht11_drv");
	device_unregister(dht11drv_class_dev);
	class_destroy(dht11drv_class);
	return 0;
}


module_init(second_drv_init);

module_exit(second_drv_exit);

MODULE_LICENSE("GPL");


