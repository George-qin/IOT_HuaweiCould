#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/termios.h>
int main()
{
    int fd;
    int ret ;
	unsigned int dht11_vals[2];
    fd = open("/dev/dht11", 0);
 	if (fd < 0)
	{
		printf("can't open!\n");
	}
	read(fd, dht11_vals, sizeof(dht11_vals));
	printf("end the tem is %d,hum is %d\n",dht11_vals[0],dht11_vals[1]);
    close(fd);
    return 0;
}
