#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include <sys/types.h>

#include <sys/stat.h>

#include <fcntl.h>

#include <stdio.h>



int main(int argc, char **argv)

{

    int fd;

    int val=1;

    fd=open("/dev/my_gpio",O_RDWR);

    if(fd<0)
    	{

    printf("can't open!\r\n");
	return 0;
    	}
	while (1) {
        val = 0;
        printf("***************************************** \n");
        printf("please select which light to turn on\n");
        printf("1 ->1:on\t 2 ->1:off\t 3 ->2:on 4 ->2:off \n");
        printf("5 ->3:on\t 6 ->3:off\t 7 ->4:on 8 ->4:off \n");
        printf("9 ->5:on\t 10 ->5:off\t 11 ->6:on 12 ->6:off \n");
        printf("***************************************** \n");
        scanf("%d", &val);
        while (val == 0) {
            printf("****************\n");
            scanf("%d", &val);
		
		 
        }

   write(fd,&val,4);}

	

    return 0;

}

