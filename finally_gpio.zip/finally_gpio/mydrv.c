#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/poll.h>
#include <linux/sched.h>
#include <linux/irq.h>
#include <asm/irq.h>
#include <asm/io.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include <linux/platform_device.h>
#include <linux/cdev.h>
#include <linux/miscdevice.h>

#include <linux/gpio.h>

#include <asm/mach-types.h>
#include <asm/gpio.h>
#include <asm/delay.h>
#include <mach/soc.h>
#include <mach/platform.h>

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>
#include <linux/ioctl.h>
#include <linux/cdev.h>
#include <linux/delay.h>
#include <plat/gpio-cfg.h>
#include <linux/gpio.h>


static struct class *mydrv_class;
static struct class_device	*mydrv_class_dev;

#define gpiobase 0XC001E000
#define GPIOE_OUT (*(volatile unsigned long*)(gpiobase))
#define GPIO_OUT_ENB (*(volatile unsigned long*)(gpiobase +8))
#define GPIO_AF0 (*(volatile unsigned long*)(gpiobase + 20))





#define LED_NUM 6

struct led {
    int gpio;
    char *name;
};

static struct led led_gpios[] = {
        {PAD_GPIO_A + 1, "led1"},
        {PAD_GPIO_A + 5, "led2"},
        {PAD_GPIO_A + 6, "led3"},
        {PAD_GPIO_A + 3, "led4"},
        {PAD_GPIO_A + 15, "led5"},
        {PAD_GPIO_A + 12, "led5"},
        
  
};


static int my_drv_open(struct inode *inode, struct file *filp)

{

    printk("my_drv_open...\r\n");

    return 0;

}












void qianjin()
{
    gpio_set_value(PAD_GPIO_A + 5, 1);
    gpio_set_value(PAD_GPIO_A + 3, 1);
    mdelay(200);
    gpio_set_value(PAD_GPIO_A + 5, 0);
    gpio_set_value(PAD_GPIO_A + 3, 0);
    printk("qianjin\n");
}
void houtui()
{
     gpio_set_value(PAD_GPIO_A + 1, 1);
     gpio_set_value(PAD_GPIO_A + 6, 1);
     mdelay(1000);
     gpio_set_value(PAD_GPIO_A + 1, 0);
     gpio_set_value(PAD_GPIO_A + 6, 0);
    printk("houtui\n");
}

void zuo_deng()
{
    gpio_set_value(PAD_GPIO_A + 5, 1);
    gpio_set_value(PAD_GPIO_A + 6, 1);
     mdelay(1000);
     gpio_set_value(PAD_GPIO_A + 5, 0);
    gpio_set_value(PAD_GPIO_A + 6, 0);
    printk("zuo_deng\n");

}

void you_deng()
{
     gpio_set_value(PAD_GPIO_A + 3, 1);
     gpio_set_value(PAD_GPIO_A + 1, 1);
      mdelay(2000);
      gpio_set_value(PAD_GPIO_A + 3, 0);
     gpio_set_value(PAD_GPIO_A + 1, 0);
    printk("youdeng\n");
}


static ssize_t my_drv_write(struct file *file, const char __user *buf, size_t count, loff_t * ppos)

{
	int num;
	int cnt = 4;
    printk("my_drv_write...\r\n");
	if(!copy_from_user(&num, buf, 4))
		{
			printk("the num is %d\n",num);

			switch (num) {
            case 1:
            	qianjin();
                break;
            case 2:
            	 houtui();
                break;
            case 3:
            	zuo_deng(); 
                break;
            case 4:
            	you_deng();
                break;
            case 5:
            	 gpio_set_value(PAD_GPIO_A + 12, 1);//���� 
                break;
            case 6:
            	gpio_set_value(PAD_GPIO_A + 12, 0); 
                break;
            case 7:
                //gpio_set_value(PAD_GPIO_A + 3, 1);
                break;
            case 8:
                //gpio_set_value(PAD_GPIO_A + 3, 0);
                break;
            case 9:
                //gpio_set_value(PAD_GPIO_A + 15, 1);
                break;
            case 10:
                //gpio_set_value(PAD_GPIO_A + 15, 0);
                break;
            case 11:
                //gpio_set_value(PAD_GPIO_A + 12, 1);
                break;
            case 12:
                //gpio_set_value(PAD_GPIO_A + 12, 0);
                break;

		}}
	else
		{
			printk("wo_bu_de");
		}
		
		

    return 0;

}



/* 这个结构是字符设备驱动程序的核心

 * 当应用程序操作设备文件时所调用的open、read、write等函数，

 * 最终会调用这个结构中指定的对应函数

 */

static struct file_operations my_drv_fops = {

    .owner  =   THIS_MODULE,    /* 这是一个宏，推向编译模块时自动创建的__this_module变量 */

    .open   =   my_drv_open,            

    .write    =    my_drv_write,       

};

int major;
static int my_drv_init(void)

{	
	int ret;
	int i;
    major = register_chrdev(0, "my_drv", &my_drv_fops);
	mydrv_class = class_create(THIS_MODULE,"my_drv");
	mydrv_class_dev = device_create(mydrv_class,NULL,MKDEV(major,0),NULL,"my_gpio");	
	for (i = 0; i < LED_NUM; i++) {
		gpio_free(led_gpios[i].gpio);
        ret = gpio_request(led_gpios[i].gpio, led_gpios[i].name);
        if (ret) {
            printk("%s: request GPIO %d for LED failed, ret = %d\n", led_gpios[i].name,
                   led_gpios[i].gpio, ret);
            return ret;
        }
		gpio_direction_output(led_gpios[i].gpio, 0);
        gpio_set_value(led_gpios[i].gpio, 0);
    }


    return ret;

}



static void my_drv_exit(void)

{

    unregister_chrdev(major, "my_drv");
	device_unregister(mydrv_class_dev);

	

}



module_init(my_drv_init);

module_exit(my_drv_init);

MODULE_AUTHOR("http://www.100ask.net");

MODULE_VERSION("0.1.0");

MODULE_DESCRIPTION("S3C2410/S3C2440 LED Driver");

MODULE_LICENSE("GPL");
