import pymysql

pymysql.install_as_MySQLdb()


start_url_di_zhi = "0.0.0.1:8848"